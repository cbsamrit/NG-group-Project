# from flask import Flask, request, jsonify, render_template
# from sklearn.preprocessing import StandardScaler
# import numpy as np
# import pickle

# app = Flask(__name__)

# with open('C:/Users/SDHRK/Desktop/Temp/model-1.pkl', 'rb') as file:
#     lda = pickle.load(file)

# customer_segments = ['Customer Segment 1', 'Customer Segment 2', 'Customer Segment 3']

# @app.route('/')
# def index():
#     return render_template('index.html')

# @app.route('/predict', methods=['POST','GET'])
# def predict():
#     if request.method == 'POST':
#         if request.content_type == 'application/json':
#             data = request.get_json()
#         elif request.content_type == 'application/x-www-form-urlencoded':
#             data = request.form
#         else:
#             return jsonify({'error': 'Invalid content type'})
#         print(data)
#         Alcohol = float(request.form['Alcohol'])
#         Malic_Acid = float(request.form['Malic_Acid'])
#         Ash = float(request.form['Ash'])
#         Ash_Alcanity = float(request.form['Ash_Alcanity'])
#         Magnesium = float(request.form['Magnesium'])
#         Total_Phenols = float(request.form['Total_Phenols'])
#         Flavanoids = float(request.form['Flavanoids'])
#         Nonflavanoid_Phenols = float(request.form['Nonflavanoid_Phenols'])
#         Proanthocyanins = float(request.form['Proanthocyanins'])
#         Color_Intensity = float(request.form['Color_Intensity'])
#         Hue = float(request.form['Hue'])
#         OD280 = float(request.form['OD280'])
#         Proline = float(request.form['Proline'])
        
#         result = lda.predict([[Alcohol, Malic_Acid, Ash, Ash_Alcanity, Magnesium,Total_Phenols,Flavanoids,Nonflavanoid_Phenols,Proanthocyanins,Color_Intensity,Hue,OD280,Proline]])
    
#     # scaler = StandardScaler()
#     # scaled_input = scaler.fit_transform(result)
    

#     # predict= scaled_input
#         labels = {
#             0: "Customers Seg 1",
#             1: "Customers Seg 2",
#             2: "Customers Seg 3"
#         }

#         prediction = {
#             'Result': result[int(result)],
#             'label': labels[int(result)]
#         }

#         return prediction
#     else:
#         # Handle GET request
#         # Add your code here if needed
#         pass   
    

# if __name__ == '__main__':
#     app.run(debug=True)











# from flask import Flask, request, jsonify, render_template
# from sklearn.preprocessing import StandardScaler
# import numpy as np
# import pickle

# app = Flask(__name__)

# with open('C:/Users/SDHRK/Desktop/Temp/model-1.pkl', 'rb') as file:
#     lda = pickle.load(file)

# customer_segments = ['Customer Segment 1', 'Customer Segment 2', 'Customer Segment 3']

# @app.route('/')
# def index():
#     return render_template('index.html')

# @app.route('/predict', methods=['POST'])
# def predict():
#     if request.content_type == 'application/json':
#         data = request.get_json()
#     elif request.content_type == 'application/x-www-form-urlencoded':
#         data = request.form
#     else:
#         return jsonify({'error': 'Invalid content type'})

#     Alcohol = float(data['Alcohol'])
#     Malic_Acid = float(data['Malic_Acid'])
#     Ash = float(data['Ash'])
#     Ash_Alcanity = float(data['Ash_Alcanity'])
#     Magnesium = float(data['Magnesium'])
#     Total_Phenols = float(data['Total_Phenols'])
#     Flavanoids = float(data['Flavanoids'])
#     Nonflavanoid_Phenols = float(data['Nonflavanoid_Phenols'])
#     Proanthocyanins = float(data['Proanthocyanins'])
#     Color_Intensity = float(data['Color_Intensity'])
#     Hue = float(data['Hue'])
#     OD280 = float(data['OD280'])
#     Proline = float(data['Proline'])
    
#     result = lda.predict([[Alcohol, Malic_Acid, Ash, Ash_Alcanity, Magnesium, Total_Phenols, Flavanoids,
#                            Nonflavanoid_Phenols, Proanthocyanins, Color_Intensity, Hue, OD280, Proline]])
    
#     labels = {
#         0: "Customer Segment 1",
#         1: "Customer Segment 2",
#         2: "Customer Segment 3"
#     }

#     prediction = {
#         'Result': int(result[0]),
#         'label': labels[int(result[0])]
#     }

#     return jsonify(prediction)

# if __name__ == '__main__':
#     app.run(debug=True)








# from flask import Flask, request, jsonify, render_template
# from sklearn.preprocessing import StandardScaler
# from flask_cors import CORS
# import numpy as np
# import pickle

# app = Flask(__name__)
# CORS(app)

# lda = pickle.load(open("C:/Users/Deepak Suryawanshi/Desktop/Project/Customer_Prediction/customer_prediction_app/clouds/model.pkl","rb"))
# sc = pickle.load(open("C:/Users/Deepak Suryawanshi/Desktop/Project/Customer_Prediction/customer_prediction_app/clouds/sc.pkl","rb"))
# lda_transformed = pickle.load(open("C:/Users/Deepak Suryawanshi/Desktop/Project/Customer_Prediction/customer_prediction_app/clouds/lda.pkl","rb"))

# customer_segments = ['Customer Segment 1', 'Customer Segment 2', 'Customer Segment 3']

# @app.route('/')
# def index():
#     return render_template('index.html')

# @app.route('/predict', methods=['POST' , 'GET'])
# def predict():
#     data = request.get_json()

#     Alcohol = float(data['alcohol'])
#     Malic_Acid = float(data['malicAcid'])
#     Ash = float(data['ash'])
#     Ash_Alcanity = float(data['ashAlcanity'])
#     Magnesium = float(data['magnesium'])
#     Total_Phenols = float(data['totalPhenols'])
#     Flavanoids = float(data['flavanoids'])
#     Nonflavanoid_Phenols = float(data['nonflavanoidPhenols'])
#     Proanthocyanins = float(data['proanthocyanins'])
#     Color_Intensity = float(data['colorIntensity'])
#     Hue = float(data['hue'])
#     OD280 = float(data['od280'])
#     Proline = float(data['proline'])

#     # Standardize the input features
#     input_features = [Alcohol, Malic_Acid, Ash, Ash_Alcanity, Magnesium, Total_Phenols,
#                       Flavanoids, Nonflavanoid_Phenols, Proanthocyanins, Color_Intensity,
#                       Hue, OD280, Proline]
#     input_features = np.array(input_features).reshape(1, -1)
#     input_features = sc.transform(input_features)

#     # Apply dimensionality reduction
#     input_features_lda = lda_transformed.transform(input_features)

#     # Prediction
#     result = lda.predict(input_features_lda)

#     x = result.tolist()
#     return  jsonify (x)

# if __name__ == '__main__':
#     app.run(debug=True)

# from flask import Flask, request, jsonify, render_template
# from sklearn.preprocessing import StandardScaler
# from flask_cors import CORS
# import numpy as np
# import pickle

# app = Flask(__name__)
# CORS(app)

# lda = pickle.load(open("C:/Users/Deepak Suryawanshi/Desktop/Project/Customer_Prediction/customer_prediction_app/clouds/model.pkl","rb"))
# sc = pickle.load(open("C:/Users/Deepak Suryawanshi/Desktop/Project/Customer_Prediction/customer_prediction_app/clouds/sc.pkl","rb"))
# lda_transformed = pickle.load(open("C:/Users/Deepak Suryawanshi/Desktop/Project/Customer_Prediction/customer_prediction_app/clouds/lda.pkl","rb"))

# customer_segments = ['Customer Segment 1', 'Customer Segment 2', 'Customer Segment 3']

# @app.route('/')
# def index():
#     return render_template('index.html')

# @app.route('/predict', methods=['POST'])
# def predict():
#     data = request.json

#     Alcohol = float(data['Alcohol'])
#     Malic_Acid = float(data['Malic Acid'])
#     Ash = float(data['Ash'])
#     Ash_Alcanity = float(data['Ash Alcanity'])
#     Magnesium = float(data['Magnesium'])
#     Total_Phenols = float(data['Total Phenols'])
#     Flavanoids = float(data['Flavanoids'])
#     Nonflavanoid_Phenols = float(data['Nonflavanoid Phenols'])
#     Proanthocyanins = float(data['Proanthocyanins'])
#     Color_Intensity = float(data['Color Intensity'])
#     Hue = float(data['Hue'])
#     OD280 = float(data['OD280'])
#     Proline = float(data['Proline'])

#     # Standardize the input features
#     input_features = [Alcohol, Malic_Acid, Ash, Ash_Alcanity, Magnesium, Total_Phenols,
#                       Flavanoids, Nonflavanoid_Phenols, Proanthocyanins, Color_Intensity,
#                       Hue, OD280, Proline]
#     input_features = np.array(input_features).reshape(1, -1)
#     input_features = sc.transform(input_features)

#     # Apply dimensionality reduction
#     input_features_lda = lda_transformed.transform(input_features)

#     # Prediction
#     result = lda.predict(input_features_lda)

#     # Convert the result to customer segment label
#     prediction = customer_segments[result[0]]

#     return jsonify({'prediction': prediction})

# if __name__ == '__main__':
#     app.run(debug=True)






# from flask import Flask, request, jsonify
# from sklearn.preprocessing import StandardScaler
# from flask_cors import CORS
# import numpy as np
# import pickle


 

# app = Flask(__name__)
# CORS(app)

# lda = pickle.load(open("C:/Users/Deepak Suryawanshi/Desktop/Project/Customer_Prediction/customer_prediction_app/clouds/model.pkl","rb"))
# sc = pickle.load(open("C:/Users/Deepak Suryawanshi/Desktop/Project/Customer_Prediction/customer_prediction_app/clouds/sc.pkl","rb"))
# lda_transformed = pickle.load(open("C:/Users/Deepak Suryawanshi/Desktop/Project/Customer_Prediction/customer_prediction_app/clouds/lda.pkl","rb"))

# customer_segments = ['Customer Segment 1', 'Customer Segment 2', 'Customer Segment 3']

# # @app.route('/')
# # def index():
# #     return app.send_static_file('index.html')

# @app.route('/predict', methods=['POST'])
# def predict():
#     data = request.get_json()

#     input_features = [float(data[key]) for key in data]

#     input_features = np.array(input_features).reshape(1, -1)
#     input_features = sc.transform(input_features)
#     input_features_lda = lda_transformed.transform(input_features)
#     result = lda.predict(input_features_lda)
#     prediction = customer_segments[result[0]]

#     return jsonify({'prediction': prediction})

# if __name__ == '__main__':
#     app.run(debug=True)





from flask import Flask, request, jsonify
from sklearn.preprocessing import StandardScaler
from flask_cors import CORS
import numpy as np
import pickle

app = Flask(__name__)
CORS(app)
print('below cors')
lda = pickle.load(open("C:/Users/Deepak Suryawanshi/Desktop/Project/Customer_Prediction/customer_prediction_app/clouds/model.pkl", "rb"))
sc = pickle.load(open("C:/Users/Deepak Suryawanshi/Desktop/Project/Customer_Prediction/customer_prediction_app/clouds/sc.pkl", "rb"))
lda_transformed = pickle.load(open("C:/Users/Deepak Suryawanshi/Desktop/Project/Customer_Prediction/customer_prediction_app/clouds/lda.pkl", "rb"))

customer_segments = ['Group 1', 'Group 2', 'Group 3']
print(customer_segments)

# @app.after_request
# def add_cors_headers(response):
#     response.headers["Access-Control-Allow-Origin"] = "http://localhost:3000"
#     response.headers["Access-Control-Allow-Headers"] = "Content-Type"
#     return response


@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    input_features = [data[key] for key in data]
    # Alcohol = float(data['alcohol'])
    # Malic_Acid = float(data['malicAcid'])
    # Ash = float(data['ash'])
    # Ash_Alcanity = float(data['ashAlcanity'])
    # Magnesium = float(data['magnesium'])
    # Total_Phenols = float(data['totalPhenols'])
    # Flavanoids = float(data['flavanoids'])
    # Nonflavanoid_Phenols = float(data['nonflavanoidPhenols'])
    # Proanthocyanins = float(data['proanthocyanins'])
    # Color_Intensity = float(data['colorIntensity'])
    # Hue = float(data['hue'])
    # OD280 = float(data['od280'])
    # Proline = float(data['proline'])

    # input_features = [Alcohol, Malic_Acid, Ash, Ash_Alcanity, Magnesium, Total_Phenols,
    #                   Flavanoids, Nonflavanoid_Phenols, Proanthocyanins, Color_Intensity,
    #                   Hue, OD280, Proline]

    input_features = np.array(input_features).reshape(1, -1)
    input_features = sc.transform(input_features)
    input_features_lda = lda_transformed.transform(input_features)
    result = lda.predict(input_features_lda)
    prediction = str(result[0])
    return jsonify({'prediction': prediction})


    # x=result.tolist()
    # return x

if __name__== '__main__':
    app.run(debug=True)

if __name__ == '__main__':
    print('into main')
    app.run(debug=True)
